# crazymath

Aplikasi game sederhana yang dibuat dengan PHP, untuk melatih kemampuan perhitungan penjumlahan.
Game rule:
* Modal awal jumlah Lives = 5
* Score awal = 0
* Setiap page akan muncul 2 bilangan bulat antara 0 - 10 secara acak, dan user diminta menjawab hasil penjumlahan kedua bil tersebut
* Setiap jawaban benar, maka score bertambah 5. Apabila salah, maka score berkurang 1 dan lives berkurang 1
* Apabila lives bernilai 0 maka GAME OVER
